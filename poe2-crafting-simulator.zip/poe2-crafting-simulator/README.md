# PoE2 裝備製作模擬器

純前端靜態網站，不需要資料庫或伺服器。

## 本機使用
直接開啟 `index.html`。

## GitHub Pages 部署
1. 建立 GitHub repository。
2. 上傳 index.html、style.css、app.js。
3. Settings → Pages → Deploy from a branch。
4. 選擇 main / root，儲存後即可取得公開網址。

## Cloudflare Pages / Netlify
將整個資料夾拖曳上傳即可。

## 注意
目前版本是可用的 MVP，內建主要裝備類型、代表性基底與通用詞綴池。若要精準重現全部 PoE2DB 資料，需另外建立版本化資料匯入流程，並遵守來源授權與網站使用條款。
